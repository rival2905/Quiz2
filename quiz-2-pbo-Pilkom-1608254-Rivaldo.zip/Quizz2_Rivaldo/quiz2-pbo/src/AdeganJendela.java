public class AdeganJendela extends Adegan{
    boolean isTerkunci = true;
    String narasiTerkunci = "Rudi mendekati jendela. Rudi mencoba membuka jendela. \"Ahh terkunci, tapi sepertinya bisa dicungkil\"";
    String narasiTerbuka  = "Rudi mencoba membuka jendela dan terbuka!";

    //constructor
    public AdeganJendela () {
        narasi = narasiTerkunci;
    }

    /* user berhasil menggunakan kunci untuk membuka Jendela */
    @Override
    public void gunakanBarang(Barang barangPilih) {
        super.gunakanBarang(barangPilih); //panggil parent
        isTerkunci = false;
        narasi = narasiTerbuka;

        //karena kunci sudah terbuka ada pilihan baru keluar dari kamar
        Adegan  adeganKeluar = new AdeganLuarJendela();
        Pilihan pilihanMenujuKeluar= new PilihanGantiAdegan(adeganKeluar,"Keluar Jendela");
        tambahPilihan(pilihanMenujuKeluar);
        adeganKeluar.tambahBarang(new Barang("pisau", "Samurai X"));
        adeganKeluar.idBarangBisaDigunakan = "pisau"; //bisa digunakan di adegan ini
    }
}
