/*
    inisialisasi adegan dsb, jalankan adegan sampai permainan selesai.

 */

public class GameEngine {
    Player oPlayer;

    public GameEngine() {
        Barang koin = new Barang("koin","uang koin");
        oPlayer = new Player();
        oPlayer.tambahBarang(koin);  //dummy saja
        //perhatikan Adegan  disini adalah class, oPlayer adalah static atribut sehingga berlaku untuk semua objek
        //artinya semua objek adegan punya objek player yang sama
        Adegan.oPlayer = oPlayer;
    }

    public void mulai() {
        oPlayer.printIdentitas();
        do {
            System.out.printf("Kesehatan Rudi: "+oPlayer.kesehatan);
            if (oPlayer.kesehatan < 60){
                if (oPlayer.modeZombie==1 && oPlayer.kesehatan<10){
                    System.out.println(" ");
                    System.out.println("Rudi hampir mati");
                    System.out.println("Segera mencari makanan dan memakannya");
                }else {
                    System.out.println(" ");
                    System.out.println("Rudi hampir kelelahan");
                    System.out.println("Segera mencari makanan dan memakannya");
                }
            }else if (oPlayer.kesehatan <=0){
                System.out.println(" ");
                System.out.println("Rudi mati, Game over");
                oPlayer.isSelesai = true;
            }
            oPlayer.adeganAktif.mainkan();
        } while (!oPlayer.isSelesai);
    }

    public static void main(String[] args) {

        Barang kunci = new Barang("kunci_besar","Kunci Besar");

        Adegan adeganPintu = new AdeganPintu();
        Adegan adeganJendela = new AdeganJendela();
        Adegan adeganMeja  = new Adegan();

        Pilihan pilihanMenujuPintu = new PilihanGantiAdegan(adeganPintu,"Menuju pintu");
        Pilihan pilihanMenujuJendela = new PilihanGantiAdegan(adeganJendela,"Menuju jendela");
        Pilihan pilihanMenujuMeja  = new PilihanGantiAdegan(adeganMeja,"Menuju meja");

        //init data cerita
        // == adegan awal
        Adegan  adeganAwal = new Adegan();
        adeganAwal.narasi =
                "Rudi terbangun disebuah ruangan yang tidak dikenal. Dia melihat sekeliling, \n" +
                "terlihat jendela, pintu dan sebuah meja kecil";
        adeganAwal.tambahPilihan(pilihanMenujuPintu);
        adeganAwal.tambahPilihan(pilihanMenujuMeja);
        adeganAwal.tambahPilihan(pilihanMenujuJendela);



        // == adegan di depan pintu
        adeganPintu.tambahPilihan(pilihanMenujuMeja); //pilihan ke meja direuse
        adeganPintu.tambahPilihan(pilihanMenujuJendela); //pilihan ke jendela direuse
        adeganPintu.idBarangBisaDigunakan = "kunci_besar"; //kunci_besar bisa digunakan di adegan ini
        adeganPintu.tambahBarang(new Barang("obeng", "Obeng bentuk bintang"));


        // == adegan di depan meja
        adeganMeja.narasi = "Rudi mendekati meja. Ada beberapa barang di atas meja";
        adeganMeja.tambahBarang(new Barang("kunci_besar", "Kunci berukuran besar"));
        adeganMeja.tambahBarang(new Barang("senter", "Senter kecil"));
        adeganMeja.tambahBarang(new Barang("coklat", "Coklat"));
        adeganMeja.tambahBarang(new Barang("lolipop", "Lolipop"));

        adeganMeja.tambahPilihan(pilihanMenujuPintu); //dari meja bisa ke pintu
        adeganMeja.tambahPilihan(pilihanMenujuJendela); //dari meja bisa ke jendela


        // == adegan di depan jendela
        adeganJendela.tambahPilihan(pilihanMenujuMeja); // pilihan ke meja di reuse
        adeganJendela.tambahPilihan(pilihanMenujuPintu);// pilihan ke pintu direuse
        adeganJendela.idBarangBisaDigunakan = "obeng"; //obeng bisa digunakan untuk mencungkil jendela

        //== init game engine
        GameEngine ge = new GameEngine();
        //ge.tambahAdegan(adeganMeja);
        ge.oPlayer.adeganAktif = adeganAwal; //start dari adegan awal
        ge.mulai();
    }
}
