public class AdeganLuarJendela extends Adegan{
    private Zombie oZombie = new Zombie();

    String narasiTerkunci = "Kamu berada diluar, zombie berdatangan\" hati hati zombie bisa saja menyerang\"cari barang di sekitar untuk berta1an diri \"";
    public AdeganLuarJendela() {
            narasi = narasiTerkunci;
    }
    /*aksi menyerang zombie dengan idBarang tertentu yang bisa digunakan untuk menyerang zombie */
    @Override
    public void gunakanBarang(Barang barangPilih) {
        super.gunakanBarang(barangPilih); //panggil parent

        //aksi mengurangi kesehtan zombie dengan mengambil nilai kekuatan pada senjata tersebut
        // menggunakan TEKNIK POLYMORPHISM
        oZombie.kesehatan -= 15;
        oZombie.printKesehatan();

        if(oZombie.kesehatan< 1){
            Adegan.oPlayer.isSelesai = true;
        }else {
            System.out.println("Zombie menyerang Rudi!");
            oPlayer.kesehatan -= oZombie.kekuatan;
        }
    }

    //aksi mengurangi kesehatan player dengan mengambil nilai kekuatan pada zombie yang menyerang player


}
