public class AdeganKoridor extends Adegan{
    String masukKoridor = "Sekarang rudi berada di koridor\" Segera cari jalan keluar";
    String bere ="Berhasil keluar\"program selesai~";
    public AdeganKoridor() {
        narasi = masukKoridor;
    }

    @Override
    public void gunakanBarang(Barang barangPilih) {
        super.gunakanBarang(barangPilih); //panggil parent
        narasi = bere;
        //karena kunci sudah terbuka ada pilihan baru keluar dari kamar
        oPlayer.isSelesai = true;

    }
}
