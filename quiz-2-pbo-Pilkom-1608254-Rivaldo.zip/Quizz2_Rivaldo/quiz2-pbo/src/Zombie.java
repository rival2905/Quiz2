public class Zombie {
    int kesehatan = 100, kekuatan = 5;


    public void printKesehatan(){
        System.out.println("Kesehatan Zombie: " + kesehatan);
    }
}
